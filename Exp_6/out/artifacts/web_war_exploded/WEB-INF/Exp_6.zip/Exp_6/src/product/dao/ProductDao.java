package product.dao;

import product.model.Product;
import product.util.DBUtil;

import java.sql.*;
import java.util.*;
import java.util.Date;

public class ProductDao {
    private static List<Product> products;
    private static int[] id = null;
    private static String[] names = null;//对商品信息进行初始化。
    private static Float[] prices = null;//对商品的价格初始化。
    private static Date[] date = null;


    static {
        String sql = null;
        sql = "select name,price,date from product";
        try {
            Connection conn = DBUtil.getConnection();
            Statement statement = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = statement.executeQuery(sql);
            rs.last();
            int max = rs.getRow();
            id = new int[max];
            names = new String[max];
            prices = new Float[max];
            date = new Date[max];
            rs.first();
            while (rs.next()) {
                for (int i = 0; i < max; i++) {
//                    id[i] = rs.getInt("id");
                    names[i] = rs.getString("name");
                    prices[i] = rs.getFloat("price");
                    date[i] = rs.getDate("date");
                    products = new ArrayList<Product>();
//                    for (int i = 0; i < names.length; i++) {//循环输出商品的信息；
                        Product p = new Product();
                        p.setId(i+1);
                        p.setName(names[i]);
                        p.setPrices(prices[i]);
                        p.setDate(date[i]);
                        products.add(p);
                    }
                }

            rs.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

//
//        products = new ArrayList<Product>();
//        for (int i = 0; i < names.length; i++) {//循环输出商品的信息；
//            Product p = new Product();
//            p.setId(i+1);
//            p.setName(names[i]);
//            p.setPrices(prices[i]);
//            p.setDate(date[i]);
//            products.add(p);
//        }
    }

    public List<Product> findAll() {// 得到所有产品
        return products;
    }


    public Product findByName(String name) { // 根据名称(支持模糊查找)查找产品
        for (Product p : products) {
            if (name == p.getName()) {
                return p;
            }

        }
        return null;
    }


    public Product findById(int id) {// 根据id查找产品
        for (Product p : products) {
            if (id == p.getId()) {
                return p;
            }

        }
        return null;
    }


    public boolean insert(String name, String price, String date) {// 插入产品
        String sql = null;
        sql = "insert into product(name,price,date) values(?,?,?)";
        try {
            Connection conn = DBUtil.getConnection();
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, name);
            statement.setFloat(2, Float.parseFloat(price));
            statement.setDate(3, java.sql.Date.valueOf(date));
            statement.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }


    public boolean update(int id, String name, String price, String date) {// 修改产品

        String sql = "update product set name = '" + name + "',price = '" + Float.parseFloat(price) + "',date = '" + java.sql.Date.valueOf(date) + "' where id = '" + id + "' ";
        try {
            Connection conn = DBUtil.getConnection();
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }


    public boolean delete(int id) {//删除产品

        String sql = "delete  from product where id = '" + id + "' ";
        try {
            Connection conn = DBUtil.getConnection();
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }
}
